using System;
using TVDB.Model;
using TVDB.Web;

internal static class TestTvdbSearch
{
    private static int Main(string[] args)
    {
        string query = args.Length == 0 ? "Lost" : args[0];
        var api = new WebInterface("APIXXXXXXXX");
        var mirror = new Mirror { Address = "http://thetvdb.com", ContainsXmlFile = true };
        var results = api.GetSeriesByName(query, "it", mirror).GetAwaiter().GetResult();
        Console.WriteLine("QUERY=" + query);
        Console.WriteLine("COUNT=" + (results == null ? -1 : results.Count));
        if (results != null)
        {
            foreach (var item in results)
            {
                Console.WriteLine(item.Id + "|" + item.Name + "|" + (item.FirstAired == DateTime.MinValue ? "" : item.FirstAired.ToString("yyyy-MM-dd")));
            }
        }
        return results != null && results.Count > 0 ? 0 : 1;
    }
}

