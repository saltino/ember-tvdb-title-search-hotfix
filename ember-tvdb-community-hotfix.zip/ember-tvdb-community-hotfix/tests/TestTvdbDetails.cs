using System;
using System.IO;
using TVDB.Model;
using TVDB.Web;

internal static class TestTvdbDetails
{
    private static int Main(string[] args)
    {
        int id = args.Length == 0 ? 445651 : int.Parse(args[0]);
        string apiKey = Environment.GetEnvironmentVariable("TVDB_API_KEY");
        if (string.IsNullOrWhiteSpace(apiKey))
        {
            Console.Error.WriteLine("Set TVDB_API_KEY=APIXXXXXXXX before running this optional live test.");
            return 2;
        }
        string testDirectory = Path.Combine(Path.GetTempPath(), "EmberTvdbHotfixTest");
        Directory.CreateDirectory(testDirectory);
        var api = new WebInterface(apiKey, testDirectory);
        var mirror = new Mirror { Address = "http://thetvdb.com", ContainsXmlFile = true };
        var details = api.GetFullSeriesById(id, "it", mirror).GetAwaiter().GetResult();
        Console.WriteLine("ID=" + id);
        Console.WriteLine("TITLE=" + (details.Series == null ? "<null>" : details.Series.Name));
        Console.WriteLine("ACTORS=" + (details.Actors == null ? 0 : details.Actors.Count));
        return details.Series == null ? 1 : 0;
    }
}

