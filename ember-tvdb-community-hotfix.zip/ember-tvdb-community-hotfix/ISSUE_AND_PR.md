# GitHub drafts

## Issue title

`TheTVDB title search returns no results; selected shows may crash in DeserializeActors`

## Issue body

Ember Media Manager 1.11.x can still retrieve a TV show when its TVDB ID is entered manually, but searching by title returns no candidates.

### Root cause

The bundled TheTVDBApi library calls the legacy `GetSeries.php` endpoint. On 16 November 2026 the endpoint returned HTTP 200 with only `<Data></Data>`.

### Reproduction

1. Open the TV-show search dialog.
2. Search for `Margo Ha Problemi Di Soldi`.
3. Before the fix: no useful title match is returned.
4. With title-search fixed but the original XML parser: selecting TVDB ID `445651` throws `NullReferenceException` in `TVDB.Model.SeriesDetails.DeserializeActors()` when an XML document has an empty root.

### Proposed community hotfix

- query the website search service currently used by TheTVDB itself;
- filter server-side and defensively client-side to `series`;
- use localized titles where present;
- force TLS 1.2;
- use a dedicated client with a 20-second timeout;
- cap JSON parsing at 5 MiB;
- make `SeriesDetails` use `DocumentElement` and empty collections safely.

### Test evidence

- `Margo Ha Problemi Di Soldi` → TVDB `445651`, localized title and 9 actors, no exception;
- `Lost` → TVDB `73739` among the results;
- `Il commissario Montalbano` → TVDB `82792`.

The movie scrapers are untouched.

### Important caveat

The search URL is a website-internal endpoint, not the supported authenticated v4 API. This is therefore proposed as an explicitly labelled community hotfix. Maintainer feedback is requested on whether to accept it temporarily or instead require a full official-v4 migration with per-user key/PIN support.

No credential is included; examples use `APIXXXXXXXX`.

## Pull-request title

`Fix TheTVDB title search and tolerate empty detail XML`

## Pull-request body

This change restores TV-show lookup by title in Ember 1.11.x and prevents the follow-up `DeserializeActors()` null-reference crash.

Changes:

- replace the retired `GetSeries.php` lookup with TheTVDB website search;
- restrict results to series and map localized titles;
- add TLS 1.2, timeout and response-size safeguards;
- parse dates invariantly;
- use a request-local `WebClient`;
- handle empty actors, banners and series XML roots.

Validated on Windows 11 x64 with Ember 1.11.1, including TVDB ID `445651`. Assembly identity remains `TVDB 1.2.0.0`.

Licensing: modified TheTVDBApi source and GPL-3.0 license are included. No API credential, PIN or token is committed; use `APIXXXXXXXX` in examples.

Known limitation: the website search endpoint is undocumented and may change. This PR is intended as a community hotfix pending a supported v4 migration decision.
