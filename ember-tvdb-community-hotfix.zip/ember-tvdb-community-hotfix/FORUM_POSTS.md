# Forum announcement drafts

Replace `[GITHUB_URL]` with the final public repository or release URL before posting.

## English — Kodi forum

### Title

`Community hotfix: TheTVDB title search for Ember Media Manager 1.11.x`

### Post

TheTVDB searches by title in Ember Media Manager 1.11.x may return no results even though manual lookup by TVDB ID still works.

The cause is the retired legacy `GetSeries.php` endpoint, which now returns an empty `<Data>` response. A second issue can then cause a `NullReferenceException` in `SeriesDetails.DeserializeActors()` when TVDB supplies an empty XML root.

We prepared an open-source GPL-3.0 community hotfix with:

- source code and unified patch;
- optional tested `TVDB.dll` plus SHA-256;
- backup, installation and rollback instructions;
- tests for title search and the real-world TVDB ID `445651` case;
- no personal API keys, PINs, databases, configurations or media paths.

Tested searches include `Lost`, `VisionQuest`, `Il commissario Montalbano`, and `Margo Ha Problemi Di Soldi`. Movie scrapers are not modified.

Important: the hotfix uses the public website's internal search endpoint, not the officially supported authenticated v4 API, so it is explicitly a best-effort interim fix pending maintainer review.

Source, binary, checksums and instructions: [GITHUB_URL]

## Deutsch — Kodinerds

### Titel

`Community-Hotfix: TheTVDB-Titelsuche für Ember Media Manager 1.11.x`

### Beitrag

Bei Ember Media Manager 1.11.x liefert die TheTVDB-Suche nach einem Serientitel teilweise keine Ergebnisse mehr, obwohl die manuelle Suche über die TVDB-ID weiterhin funktioniert.

Ursache ist der veraltete Endpunkt `GetSeries.php`, der inzwischen nur noch eine leere `<Data>`-Antwort zurückgibt. Zusätzlich konnte beim Laden der Details eine `NullReferenceException` in `SeriesDetails.DeserializeActors()` auftreten, wenn TheTVDB ein leeres XML-Wurzelelement liefert.

Wir haben deshalb einen quelloffenen Community-Hotfix unter GPL-3.0 vorbereitet:

- vollständiger Quellcode und Unified Patch;
- optional getestete `TVDB.dll` mit SHA-256-Prüfsumme;
- Anleitung für Backup, Installation und Wiederherstellung;
- Tests für die Titelsuche und den realen Fall TVDB-ID `445651`;
- keine persönlichen API-Schlüssel, PINs, Datenbanken, Konfigurationen oder Medienpfade.

Getestet wurden unter anderem `Lost`, `VisionQuest`, `Il commissario Montalbano` und `Margo Ha Problemi Di Soldi`. Die Film-Scraper werden nicht verändert.

Wichtiger Hinweis: Der Hotfix verwendet den internen Suchdienst der öffentlichen TheTVDB-Webseite und nicht die offiziell unterstützte authentifizierte v4-API. Daher ist dies ausdrücklich eine vorläufige Best-Effort-Lösung bis zur Prüfung durch die Maintainer.

Quellcode, Binärdatei, Prüfsummen und Anleitung: [GITHUB_URL]

## Italiano

### Titolo

`Hotfix comunitario: ricerca per titolo TheTVDB in Ember Media Manager 1.11.x`

### Messaggio

In Ember Media Manager 1.11.x la ricerca TheTVDB per titolo può non restituire risultati, mentre la ricerca manuale tramite ID continua a funzionare.

La causa è il vecchio endpoint `GetSeries.php`, che ora restituisce una risposta `<Data>` vuota. È stato corretto anche il successivo errore `NullReferenceException` in `SeriesDetails.DeserializeActors()` con documenti XML vuoti.

Abbiamo preparato un hotfix comunitario GPL-3.0 con sorgenti, patch, DLL opzionale verificata, checksum, test e istruzioni di backup/ripristino. Non contiene chiavi API personali, PIN, database, configurazioni o percorsi multimediali. Lo scraper film non viene modificato.

Nota: la ricerca usa il servizio interno del sito pubblico TheTVDB, non l'API v4 ufficialmente supportata; è quindi una soluzione provvisoria best-effort in attesa della valutazione dei maintainer.

Materiale: [GITHUB_URL]
