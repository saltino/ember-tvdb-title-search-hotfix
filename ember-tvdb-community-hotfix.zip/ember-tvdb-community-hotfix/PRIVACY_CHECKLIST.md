# Publication privacy checklist

- [x] No Ember profile or configuration file included
- [x] No database included
- [x] No application log included
- [x] No media-library path included
- [x] No personal API key, PIN, token, cookie or authorization header included
- [x] Credential placeholder standardized as `APIXXXXXXXX`
- [x] Modified source and GPL-3.0 license included
- [x] Optional binary accompanied by source, patch and checksum
- [ ] Replace `[GITHUB_URL]` only after the public repository/release exists
- [ ] Review the final GitHub diff once more before publishing
